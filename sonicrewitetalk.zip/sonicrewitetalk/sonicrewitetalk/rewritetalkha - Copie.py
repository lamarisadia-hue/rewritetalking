import tkinter as tk
import random
import time
import threading
import json
from PIL import Image

# =========================
# STYLE GLOBAL
# =========================

BG = "#000000"
GREEN = "#00FF00"
FONT = ("Consolas", 12)

# =========================
# IA – APPRENTISSAGE
# =========================

def charger_conversations():
    try:
        with open("conversations.json", "r") as f:
            return json.load(f)
    except:
        return {}

def sauvegarder_conversations(conv):
    with open("conversations.json", "w") as f:
        json.dump(conv, f, indent=4)

# =========================
# EFFET TYPING
# =========================

def typer(zone, texte):
    zone.config(state="normal")
    for c in texte:
        zone.insert(tk.END, c)
        zone.update()
        time.sleep(0.03)
    zone.insert(tk.END, "\n")
    zone.config(state="disabled")

# =========================
# ÉCRAN DE CHARGEMENT
# =========================

def ecran_chargement():
    load = tk.Toplevel()
    load.title("Chargement IA")
    load.geometry("550x700")
    load.configure(bg=BG)

    tk.Label(
        load, text="INITIALISATION DU SYSTÈME",
        fg=GREEN, bg=BG, font=("Consolas", 20)
    ).pack(pady=20)

    zone = tk.Text(load, bg=BG, fg=GREEN, font=FONT, height=15)
    zone.pack(padx=20, pady=20)
    zone.config(state="disabled")

    lignes = [
        "Chargement des bibliothèques...",
        "Initialisation mémoire IA...",
        "Chargement conversations.json",
        "Activation apprentissage...",
        "Préparation interface graphique...",
        "Démarrage du noyau IA...",
        "SYSTÈME PRÊT"
    ]

    def charger():
        for l in lignes:
            typer(zone, l)
            time.sleep(0.7)
        load.destroy()
        lancer_ia()

    threading.Thread(target=charger).start()

# =========================
# FENÊTRE IA
# =========================

def lancer_ia():
    conversations = charger_conversations()
    question_temp = {"q": None}

    ia = tk.Toplevel()
    ia.title("IA")
    ia.geometry("550x700")
    ia.configure(bg=BG)

    chat = tk.Text(ia, bg=BG, fg=GREEN, font=FONT, wrap=tk.WORD)
    chat.pack(expand=True, fill="both", padx=10, pady=10)
    chat.config(state="disabled")

    entry = tk.Entry(ia, bg=BG, fg=GREEN, font=("Consolas", 14))
    entry.pack(fill="x", padx=10, pady=5)

    def afficher(txt):
        chat.config(state="normal")
        chat.insert(tk.END, txt + "\n")
        chat.see(tk.END)
        chat.config(state="disabled")

    def envoyer():
        msg = entry.get().strip()
        if not msg:
            return
        entry.delete(0, tk.END)
        afficher(f"> {msg}")

        rep = conversations.get(
            msg.lower(),
            random.choice([
                "Je ne connais pas encore la réponse.",
                "Tu peux me l'apprendre.",
                "Réponse inconnue."
            ])
        )
        afficher(f"IA : {rep}")

    def apprendre():
        q = entry.get().strip()
        if not q:
            afficher("IA : Entre une question.")
            return
        question_temp["q"] = q.lower()
        entry.delete(0, tk.END)
        afficher(f"> {q}")
        afficher("IA : Quelle est la réponse ?")

    def enregistrer():
        r = entry.get().strip()
        if not r or not question_temp["q"]:
            afficher("IA : Rien à enregistrer.")
            return
        conversations[question_temp["q"]] = r
        sauvegarder_conversations(conversations)
        afficher(f"IA : Apprentissage réussi ➜ {r}")
        question_temp["q"] = None
        entry.delete(0, tk.END)

    btn_frame = tk.Frame(ia, bg=BG)
    btn_frame.pack(pady=10)

    for txt, cmd in [
        ("ENVOYER", envoyer),
        ("APPRENDRE", apprendre),
        ("ENREGISTRER", enregistrer)
    ]:
        tk.Button(
            btn_frame, text=txt,
            bg=GREEN, fg="black",
            font=FONT, width=12,
            command=cmd
        ).pack(side="left", padx=5)

# =========================
# DASH
# =========================

def lancer_dash():
    dash = tk.Toplevel()
    dash.title("DASH")
    dash.geometry("400x450")
    dash.configure(bg=BG)

    def calcul(op):
        try:
            a = float(e1.get())
            b = float(e2.get())
            if op == "add": r = a + b
            if op == "mul": r = a * b
            if op == "div": r = a / b
            res.config(text=f"Résultat : {r}")
        except:
            res.config(text="Erreur")

    tk.Label(dash, text="Nombre 1", fg=GREEN, bg=BG).pack()
    e1 = tk.Entry(dash, bg=BG, fg=GREEN)
    e1.pack()

    tk.Label(dash, text="Nombre 2", fg=GREEN, bg=BG).pack()
    e2 = tk.Entry(dash, bg=BG, fg=GREEN)
    e2.pack()

    for t, o in [("Addition","add"),("Multiplication","mul"),("Division","div")]:
        tk.Button(
            dash, text=t, bg=GREEN, fg="black",
            command=lambda op=o: calcul(op)
        ).pack(pady=5)

    res = tk.Label(dash, text="Résultat :", fg=GREEN, bg=BG)
    res.pack(pady=10)

    def pixel(c):
        img = Image.new("RGB", (40, 40), "white")
        img.putpixel((20,20), (0,0,255) if c=="bleu" else (0,255,0))
        img.show()

    tk.Button(dash, text="Pixel Bleu", bg=GREEN, fg="black",
              command=lambda: pixel("bleu")).pack(pady=5)
    tk.Button(dash, text="Pixel Vert", bg=GREEN, fg="black",
              command=lambda: pixel("vert")).pack(pady=5)

# =========================
# MENU PRINCIPAL
# =========================

root = tk.Tk()
root.title("SYSTEM MENU")
root.geometry("400x300")
root.configure(bg=BG)

frame = tk.Frame(root, bg=BG, highlightbackground=GREEN, highlightthickness=2)
frame.pack(expand=True, fill="both", padx=20, pady=20)

tk.Label(
    frame, text="MENU PRINCIPAL",
    fg=GREEN, bg=BG, font=("Consolas", 18)
).pack(pady=20)

tk.Button(
    frame, text=" LANCER IA",
    bg=GREEN, fg="black",
    font=FONT, command=ecran_chargement
).pack(pady=10, fill="x")

tk.Button(
    frame, text=" LANCER DASH",
    bg=GREEN, fg="black",
    font=FONT, command=lancer_dash
).pack(pady=10, fill="x")

root.mainloop()
